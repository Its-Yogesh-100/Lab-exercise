

//Write a program in Java to print “Hello World”.

public class Main
{
	public static void main(String[] args) {
	    
	    // Question number 1
		System.out.println("\t\tHello World\n");
		
	
	    // Question number 2-a
		Pattern_A p=new Pattern_A();
		p.printTriangle();
		System.out.println("\n\n");
		
		//Question number 2-b
		Pattern_B pb=new Pattern_B();
		pb.reverse();
		
		
		//Question nubmer 3
		table tt=new table();
		tt.tables(5);
		
	}
}


