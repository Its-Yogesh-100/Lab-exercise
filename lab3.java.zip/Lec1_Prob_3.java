class table{
    
    
    
    public static void tables(int n)
    {
        
        for(int i=1;i<=10;i++)
        {
            System.out.println(n+"*"+i+" = "+n*i);
        }
    }
}